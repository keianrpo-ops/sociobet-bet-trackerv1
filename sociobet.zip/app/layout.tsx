import React from 'react';
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "SocioBet Dashboard",
  description: "Professional sports betting management",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <head>
        {/* Tailwind CDN maintained for compatibility with existing styling approach */}
        <script src="https://cdn.tailwindcss.com"></script>
        <script dangerouslySetInnerHTML={{__html: `
          tailwind.config = {
            darkMode: 'class',
            theme: {
              extend: {
                fontFamily: { sans: ['Inter', 'sans-serif'] },
                colors: { slate: { 850: '#1e293b', 900: '#0f172a' } }
              }
            }
          }
        `}} />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  );
}